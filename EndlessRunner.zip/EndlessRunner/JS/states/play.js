/**
 * Created by Adam on 31/01/2017.
 */
var PlayState = {
  create: function () {
      //Create Objects
      this.player = new Player(100,game.world.height/2);
       this.level = new Level();

      //Create a variable for key press for player jump
      this.jumpKey = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);

      //Apply Physics
      game.physics.arcade.gravity.y = 200;
  },
     update: function () {
         //Update Level
        this.level.updateLevel();

         //Check to see if player needs updated
         if(this.jumpKey.isDown){
             this.player.jump();
         }

        //Check for collisions
         for(var i = 0; i < this.level.levelArray.length; i++){

             game.physics.arcade.collide(this.player.sprite, this.level.levelArray[i].sprite);
         }

    }
};