/**

 */

var SplashState = function () {
    
};