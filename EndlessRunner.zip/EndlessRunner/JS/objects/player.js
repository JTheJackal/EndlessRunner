/**
 * Player Object
 *
 * Changes :
 *
 *
 *
 * Bugs :
 */

var Player = function(x, y){
    //Set Properties
    this.x = x;
    this.y = y;
    this.sprite = game.add.sprite(this.x, this.y, "player");
    this.velY = 2;
    this.jumpForce = 5.0; //This was here but is unused?

    //enabled Physics
    game.physics.arcade.enable(this.sprite);

    //Set Physics properties
    this.sprite.body.bounce.y = 0.55;
    this.sprite.body.allowGravity = true;
    this.sprite.body.immovable = false;
};

//Apply Gravity
Player.prototype.applyGravity = function(){

    this.sprite.y += this.velY;
};

//Jump Sprite
Player.prototype.jump = function(){
    this.sprite.body.velocity.y = -250;
};
