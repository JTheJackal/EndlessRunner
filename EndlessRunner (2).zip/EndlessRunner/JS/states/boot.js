/**
 * Created by Adam on 31/01/2017.
 */

var BootState = function () {
    
};